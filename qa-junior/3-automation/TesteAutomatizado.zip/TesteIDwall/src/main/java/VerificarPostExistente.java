
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.Keys;



public class VerificarPostExistente {


			@Test
			public void Pesquisar() {
			WebDriver driver = new FirefoxDriver();
			driver.manage().window().maximize();
			driver.get("https://blog.idwall.co/");
			driver.findElement(By.id("top-search")).click();
			driver.findElement(By.id("s")).sendKeys("Como criar uma pol�tica de seguran�a da informa��o");
			driver.findElement(By.id("s")).sendKeys(Keys.ENTER);
			driver.quit();
			}
}